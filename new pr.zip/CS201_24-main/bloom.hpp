#include<bits/stdc++.h>
using namespace std;
#ifndef BLOOM_H
#define BLOOM_H
int h1(string s, int arrSize);
int h2(string s, int arrSize);
int h3(string s, int arrSize);
int h4(string s, int arrSize);
int lookup(bool *bit, int arr, string s);
int insert(bool *bit, int Size, string s);
#endif


